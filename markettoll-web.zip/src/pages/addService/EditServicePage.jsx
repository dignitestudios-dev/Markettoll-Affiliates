import React from "react";
import EditServiceForm from "../../components/AddService/EditServiceForm";

const EditServicePage = () => {
  return (
    <div>
      <EditServiceForm />
    </div>
  );
};

export default EditServicePage;
