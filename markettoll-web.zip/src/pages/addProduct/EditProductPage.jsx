import React from "react";
import EditProductForm from "../../components/AddProduct/EditProductForm";

const EditProductPage = () => {
  return (
    <div>
      <EditProductForm />
    </div>
  );
};

export default EditProductPage;
