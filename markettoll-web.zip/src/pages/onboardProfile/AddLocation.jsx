import React from "react";
import AddLocationForm from "../../components/OnboardProfileSetup/AddLocationForm";

const AddLocation = () => {
  return (
    <div className="padding-x py-6">
      <AddLocationForm />
    </div>
  );
};

export default AddLocation;
