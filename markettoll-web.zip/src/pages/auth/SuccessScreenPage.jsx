import React from "react";
import SuccessScreen from "../../components/Auth/SuccessScreen";

const SuccessScreenPage = () => {
  return (
    <div className="padding-x">
      <SuccessScreen />
    </div>
  );
};

export default SuccessScreenPage;
