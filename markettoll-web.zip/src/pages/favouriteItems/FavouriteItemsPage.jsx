import React from "react";
import FavouriteItemsList from "../../components/FavourtieItems/FavouriteItemsList";

const FavouriteItemsPage = () => {
  return (
    <div className="padding-x py-6">
      <FavouriteItemsList />
    </div>
  );
};

export default FavouriteItemsPage;
