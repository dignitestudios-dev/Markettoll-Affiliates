import React from "react";
import UpdatePasswordForm from "../../components/Auth/UpdatePasswordForm";

const UpdatePasswordPage = () => {
  return (
    <div className="padding-x py-6">
      <UpdatePasswordForm />
    </div>
  );
};

export default UpdatePasswordPage;
