import React from "react";
import AddProductForm from "../../components/AddProduct/AddProductForm";

const AddProductPage = () => {
  return (
    <div>
      <AddProductForm />
    </div>
  );
};

export default AddProductPage;
