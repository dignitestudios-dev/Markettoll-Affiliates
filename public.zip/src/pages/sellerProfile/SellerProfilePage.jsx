import React from "react";
import SellerProfile from "../../components/sellerProfile/SellerProfile";

const SellerProfilePage = () => {
  return (
    <div>
      <SellerProfile />
    </div>
  );
};

export default SellerProfilePage;
