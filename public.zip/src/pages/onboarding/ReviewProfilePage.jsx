import React from "react";
import ReviewProfileForm from "../../components/Onboarding/ReviewProfileForm";

const ReviewProfilePage = () => {
  return (
    <div className="padding-x py-6">
      <ReviewProfileForm />
    </div>
  );
};

export default ReviewProfilePage;
