import React from "react";
import AddServiceForm from "../../components/AddService/AddServiceForm";

const AddServicePage = () => {
  return (
    <div>
      <AddServiceForm />
    </div>
  );
};

export default AddServicePage;
